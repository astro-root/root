import { initSearch } from './search';
import { initMeteors } from './meteors';

const root = document.documentElement;

// ---- ヘッダー: スクロールで下線
const header = document.getElementById('site-header');
const setScrolled = () => { if (header) header.dataset.scrolled = window.scrollY > 8 ? 'true' : 'false'; };
setScrolled();
window.addEventListener('scroll', setScrolled, { passive: true });

// ---- テーマ（未設定ならOSに従う。選択後は localStorage に保存）
document.getElementById('theme-toggle')?.addEventListener('click', () => {
  const current = root.getAttribute('data-theme');
  const isDark = current === 'dark' || (!current && matchMedia('(prefers-color-scheme: dark)').matches);
  const next = isDark ? 'light' : 'dark';
  root.setAttribute('data-theme', next);
  try { localStorage.setItem('rl-theme', next); } catch { /* 保存できなくても動作する */ }
});

// ---- メニュー（全画面オーバーレイ）
const toggle = document.getElementById('nav-toggle');
const overlay = document.getElementById('nav-overlay');
function setMenu(open: boolean) {
  if (!toggle || !overlay) return;
  overlay.hidden = !open;
  toggle.setAttribute('aria-expanded', String(open));
  document.body.style.overflow = open ? 'hidden' : '';
}
toggle?.addEventListener('click', () => setMenu(overlay?.hidden ?? true));
overlay?.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => setMenu(false)));
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && overlay && !overlay.hidden) { setMenu(false); toggle?.focus(); } });
matchMedia('(min-width: 721px)').addEventListener('change', (e) => { if (e.matches) setMenu(false); });

// ---- オープニング（再生済みの記録のみ。アニメーション自体はCSS）
const opening = document.getElementById('opening');
if (opening) {
  const finish = () => { try { sessionStorage.setItem('rl-opening-seen', '1'); } catch { /* noop */ } };
  document.getElementById('opening-skip')?.addEventListener('click', () => { opening.classList.add('is-skipping'); finish(); });
  opening.addEventListener('animationend', (e) => { if (e.target === opening) { finish(); opening.remove(); } });
}

// ---- スクロール表示
if (root.classList.contains('reveal-on')) {
  const els = document.querySelectorAll<HTMLElement>('.reveal');
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      for (const en of entries) if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); }
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    els.forEach((el) => io.observe(el));
  } else els.forEach((el) => el.classList.add('is-in'));
}

initSearch();
initMeteors();
