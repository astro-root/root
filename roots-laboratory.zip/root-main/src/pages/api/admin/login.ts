import type { APIRoute } from 'astro';
import { clientKey, createSession, isHttps, dummyVerify, rateLimit, rateLimitCheck, rateLimitReset, sessionCookie, verifyPassword } from '@/lib/auth';
import { EMAIL_RE, json } from '@/lib/validate';

export const prerender = false;

const WINDOW = 900; // 15分
const MAX_PER_EMAIL = 5;
const MAX_PER_IP = 10;

export const POST: APIRoute = async ({ request, locals, url }) => {
  const db = locals.db;
  if (!db) {
    return json({ ok: false, error: 'db_unavailable', message: 'データベース（D1）に接続できません。D1 バインディング「DB」の設定を確認してください（docs/DEPLOY.md）。' }, 503);
  }

  let body: { email?: unknown; password?: unknown } = {};
  try { body = await request.json(); } catch { return json({ ok: false, error: 'bad_request' }, 400); }
  const email = typeof body.email === 'string' ? body.email.trim().toLowerCase().slice(0, 254) : '';
  const password = typeof body.password === 'string' ? body.password.slice(0, 200) : '';

  // 管理者が1人もいない場合は、ロックや「パスワード誤り」ではなく、原因を正しく伝える。
  // （管理者がいなければ誰もログインできないため、これを伝えても安全性は下がらない）
  let adminCount = 0;
  try {
    adminCount = (await db.prepare('SELECT COUNT(*) AS n FROM admins').first<{ n: number }>())?.n ?? 0;
  } catch {
    return json({ ok: false, error: 'db_not_migrated', message: 'データベースにテーブルがありません。マイグレーションを適用してください（ローカル: npm run db:migrate:local）。' }, 503);
  }
  if (adminCount === 0) {
    return json({ ok: false, error: 'no_admin', message: '管理者アカウントがまだ作成されていません。ターミナルで「npm run admin:create」を実行してください。' }, 409);
  }

  const ipKey = `login:ip:${await clientKey(request, locals.env.IP_HASH_SALT)}`;
  const emailKey = `login:email:${email || '-'}`;

  // ブロック判定のみ（成功したログインではカウントしない）
  const byIp = await rateLimitCheck(db, ipKey, MAX_PER_IP, WINDOW);
  const byEmail = await rateLimitCheck(db, emailKey, MAX_PER_EMAIL, WINDOW);
  if (!byIp.ok || !byEmail.ok) {
    const wait = Math.max(byIp.retryAfter, byEmail.retryAfter);
    return json(
      { ok: false, error: 'rate_limited', message: `ログインの失敗が続いたため、一時的に制限しています。約${Math.ceil(wait / 60)}分後にもう一度お試しください。` },
      429,
      { 'Retry-After': String(wait) }
    );
  }

  const fail = async () => {
    // 失敗のみカウント
    await rateLimit(db, ipKey, MAX_PER_IP, WINDOW);
    await rateLimit(db, emailKey, MAX_PER_EMAIL, WINDOW);
    return json({ ok: false, error: 'invalid_credentials', message: 'メールアドレスまたはパスワードが正しくありません。' }, 401);
  };
  if (!EMAIL_RE.test(email) || !password) { await dummyVerify(password); return fail(); }

  const admin = await db.prepare('SELECT id, password_hash FROM admins WHERE email = ?').bind(email).first<{ id: number; password_hash: string }>();
  if (!admin) { await dummyVerify(password); return fail(); }
  if (!(await verifyPassword(password, admin.password_hash))) return fail();

  // 成功: このメール・このIPの失敗カウントを解除
  await rateLimitReset(db, emailKey);
  await rateLimitReset(db, ipKey);
  const { token, maxAge } = await createSession(db, admin.id);
  const res = json({ ok: true });
  res.headers.append('Set-Cookie', sessionCookie(token, maxAge, isHttps(request, url)));
  return res;
};
