// 開発専用: workerd が動かない環境（一部のARM Chromebook など）向けの、D1 互換アダプタ（node:sqlite）。
// アプリが使う D1 の API（prepare / bind / first / all / run）だけを実装している。
// 本番（Cloudflare）では使われない: middleware から `import.meta.env.DEV` かつ RL_NODE_DB=1 のときだけ動的に読み込む。
import fs from 'node:fs';
import path from 'node:path';

type Param = string | number | null | Uint8Array;

function norm(v: unknown): Param {
  if (v === undefined || v === null) return null;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (v instanceof ArrayBuffer) return new Uint8Array(v);
  return v as Param;
}

class Stmt {
  constructor(private db: any, private sql: string, private params: Param[] = []) {}
  bind(...p: unknown[]) { return new Stmt(this.db, this.sql, p.map(norm)); }
  async first<T = unknown>(): Promise<T | null> { return (this.db.prepare(this.sql).get(...this.params) as T) ?? null; }
  async all<T = unknown>() { return { results: this.db.prepare(this.sql).all(...this.params) as T[], success: true, meta: {} }; }
  async run() {
    const r = this.db.prepare(this.sql).run(...this.params);
    return { success: true, results: [], meta: { changes: Number(r.changes), last_row_id: Number(r.lastInsertRowid) } };
  }
}

class NodeD1 {
  constructor(private db: any) {}
  prepare(sql: string) { return new Stmt(this.db, sql); }
  async exec(sql: string) { this.db.exec(sql); return { count: 1, duration: 0 }; }
}

const g = globalThis as { __rlNodeD1?: Promise<D1Database> };

/** ホットリロードで作り直されないよう、プロセス内で1つだけ開く */
export function openNodeD1(): Promise<D1Database> {
  g.__rlNodeD1 ??= (async () => {
    const file = path.resolve(process.env.RL_NODE_DB_PATH || '.local-db/roots.sqlite');
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const mod = 'node:sqlite'; // 変数経由にして、バンドラが解決しようとしないようにする
    const { DatabaseSync } = await import(/* @vite-ignore */ mod);
    const db = new DatabaseSync(file);
    db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
    return new NodeD1(db) as unknown as D1Database;
  })();
  return g.__rlNodeD1;
}

/** .dev.vars（KEY=VALUE）を読む。本番のシークレットに相当するローカル値 */
export function readDevVars(): Record<string, string> {
  const out: Record<string, string> = {};
  try {
    for (const line of fs.readFileSync('.dev.vars', 'utf8').split('\n')) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
      if (m && !line.trim().startsWith('#')) out[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
  } catch { /* 無ければ空 */ }
  return out;
}
