// E2E専用のローカルDBを毎回作り直す。開発用DB（.wrangler / .local-db）には触れない。
// モード（wrangler / node）は scripts/db.mjs が自動判定する（RL_NODE_DB=1 で node を強制）。
// playwright.config.ts の webServer コマンドから、サーバー起動前に実行される。
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';

fs.rmSync('.e2e', { recursive: true, force: true });
fs.mkdirSync('.e2e', { recursive: true });
const env = { ...process.env, D1_PERSIST_DIR: '.e2e/state', RL_NODE_DB_PATH: '.e2e/node.sqlite' };
const run = (cmd, args, extra = {}) => execFileSync(cmd, args, { env: { ...env, ...extra }, stdio: 'pipe' });
run('node', ['scripts/build-seed.mjs']);
run('node', ['scripts/db.mjs', 'migrate']);
run('node', ['scripts/db.mjs', 'seed']);
run('node', ['scripts/create-admin.mjs'], { ADMIN_EMAIL: 'e2e-admin@example.test', ADMIN_PASSWORD: 'e2e-password-123456' });
console.log('e2e database ready (' + run('node', ['scripts/db.mjs', 'mode']).toString().trim() + ')');
