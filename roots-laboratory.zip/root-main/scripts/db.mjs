#!/usr/bin/env node
// ローカルDB操作の窓口。モード（wrangler / node）を自動判定して同じコマンドで扱えるようにする。
//   node scripts/db.mjs mode                 現在のモードを表示（wrangler | node）
//   node scripts/db.mjs migrate              マイグレーション適用（ローカル）
//   node scripts/db.mjs seed                 db/seed.sql を投入（ローカル）
//   node scripts/db.mjs count <table>        行数を表示（ローカル。無ければ 0）
//   node scripts/db.mjs file <sql> [--remote]  SQLファイルを実行（--remote は本番D1。workerd 不要）
//   node scripts/db.mjs reset                ローカルDBを削除
// E2E等で分離したい場合: D1_PERSIST_DIR（wrangler）/ RL_NODE_DB_PATH（node）
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { ROOT, dbMode } from './lib/mode.mjs';

const [cmd, arg, flag] = process.argv.slice(2);
const mode = dbMode();
const persist = process.env.D1_PERSIST_DIR ? ['--persist-to', process.env.D1_PERSIST_DIR] : [];

function wrangler(args, { capture = false } = {}) {
  const r = spawnSync('npx', ['wrangler', ...args], { cwd: ROOT, encoding: 'utf8', stdio: capture ? ['ignore', 'pipe', 'pipe'] : ['ignore', 'pipe', 'pipe'] });
  if (r.status !== 0) {
    const text = `${r.stdout}${r.stderr}`.replace(/\x1b\[[0-9;?]*[a-zA-Z]/g, '').split('\n').filter((l) => l.trim()).slice(-15).join('\n');
    console.error(`✗ wrangler ${args.slice(0, 3).join(' ')} が失敗しました\n${text}`);
    if (/EPIPE|workerd|Illegal instruction|tcmalloc/i.test(text)) console.error('\n※ このPCでは workerd が動いていません。RL_NODE_DB=1 を付けると Node 版のローカルDBで動かせます。');
    process.exit(r.status ?? 1);
  }
  return r.stdout;
}

if (cmd === 'mode') { console.log(mode); process.exit(0); }

if (cmd === 'file' && flag === '--remote') {
  wrangler(['d1', 'execute', 'DB', '--remote', '--file', path.resolve(arg)]);
  process.exit(0);
}

if (mode === 'node') {
  const { openDb, migrate, dbFile } = await import('./lib/node-sqlite.mjs');
  if (cmd === 'reset') { for (const s of ['', '-wal', '-shm']) fs.rmSync(dbFile() + s, { force: true }); console.log('ローカルDBを削除しました'); process.exit(0); }
  const db = await openDb();
  if (cmd === 'migrate') { const done = migrate(db); console.log(done.length ? `適用: ${done.join(', ')}` : '適用済み（変更なし）'); }
  else if (cmd === 'seed') { db.exec(fs.readFileSync(path.join(ROOT, 'db/seed.sql'), 'utf8')); console.log('seed 投入'); }
  else if (cmd === 'file') { db.exec(fs.readFileSync(path.resolve(arg), 'utf8')); }
  else if (cmd === 'count') {
    if (!/^[a-z_]+$/.test(arg || '')) { console.error('テーブル名が不正です'); process.exit(1); }
    try { console.log(db.prepare(`SELECT COUNT(*) AS n FROM ${arg}`).get().n); } catch { console.log(0); }
  } else { console.error('使い方: node scripts/db.mjs <mode|migrate|seed|count TABLE|file SQL [--remote]|reset>'); process.exit(1); }
  db.close();
} else {
  if (cmd === 'reset') { fs.rmSync(path.join(ROOT, process.env.D1_PERSIST_DIR || '.wrangler/state'), { recursive: true, force: true }); console.log('ローカルDBを削除しました'); process.exit(0); }
  if (cmd === 'migrate') { wrangler(['d1', 'migrations', 'apply', 'DB', '--local', ...persist]); console.log('マイグレーション適用'); }
  else if (cmd === 'seed') { wrangler(['d1', 'execute', 'DB', '--local', ...persist, '--file', path.join(ROOT, 'db/seed.sql')]); console.log('seed 投入'); }
  else if (cmd === 'file') { wrangler(['d1', 'execute', 'DB', '--local', ...persist, '--file', path.resolve(arg)]); }
  else if (cmd === 'count') {
    if (!/^[a-z_]+$/.test(arg || '')) { console.error('テーブル名が不正です'); process.exit(1); }
    const r = spawnSync('npx', ['wrangler', 'd1', 'execute', 'DB', '--local', ...persist, '--json', '--command', `SELECT COUNT(*) AS n FROM ${arg}`], { cwd: ROOT, encoding: 'utf8' });
    try { console.log(JSON.parse(r.stdout)[0].results[0].n); } catch { console.log(0); }
  } else { console.error('使い方: node scripts/db.mjs <mode|migrate|seed|count TABLE|file SQL [--remote]|reset>'); process.exit(1); }
}
