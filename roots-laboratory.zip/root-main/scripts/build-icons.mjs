// public/apple-touch-icon.png（元画像・180x180）から各種アイコンを生成する。
// 元画像より大きいサイズは拡大になるため、必要最小限（192px）に留めている。
import fs from 'node:fs';
import path from 'node:path';
import sharp from 'sharp';

const pub = path.resolve(import.meta.dirname, '../public');
const src = fs.readFileSync(path.join(pub, 'apple-touch-icon.png'));
const png = (size) => sharp(src).resize(size, size, { kernel: 'lanczos3' }).png({ compressionLevel: 9 }).toBuffer();

// favicon.ico（PNG埋め込み形式: 16 / 32 / 48）
const sizes = [16, 32, 48];
const images = await Promise.all(sizes.map(png));
const header = Buffer.alloc(6);
header.writeUInt16LE(0, 0); header.writeUInt16LE(1, 2); header.writeUInt16LE(sizes.length, 4);
let offset = 6 + 16 * sizes.length;
const dir = sizes.map((s, i) => {
  const e = Buffer.alloc(16);
  e.writeUInt8(s, 0); e.writeUInt8(s, 1); e.writeUInt8(0, 2); e.writeUInt8(0, 3);
  e.writeUInt16LE(1, 4); e.writeUInt16LE(32, 6); e.writeUInt32LE(images[i].length, 8); e.writeUInt32LE(offset, 12);
  offset += images[i].length;
  return e;
});
fs.writeFileSync(path.join(pub, 'favicon.ico'), Buffer.concat([header, ...dir, ...images]));

fs.writeFileSync(path.join(pub, 'favicon-32.png'), await png(32));
fs.writeFileSync(path.join(pub, 'icon-192.png'), await png(192));

// favicon.svg: 元画像をそのまま埋め込む（デザインを改変しない）
fs.writeFileSync(
  path.join(pub, 'favicon.svg'),
  `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 180 180" width="180" height="180"><image width="180" height="180" xlink:href="data:image/png;base64,${src.toString('base64')}"/></svg>\n`
);

// OGP画像 1200x630: 元サイトの意匠（外枠・同心円・等幅の一行）を踏襲。ダークは青みがかった黒。
// ※ 文字はOSのフォント(Noto Sans CJK JP 等)で描画される。再生成する環境に日本語フォントが必要。
const iconB64 = src.toString('base64');
const og = `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1200" height="630" viewBox="0 0 1200 630">
  <rect width="1200" height="630" fill="#080b12"/>
  <rect width="1200" height="630" fill="none" stroke="#1b2232" stroke-width="2"/>
  <g opacity="0.5" stroke="#8fa0d6" stroke-width="1" fill="none">
    <ellipse cx="1000" cy="120" rx="260" ry="260"/>
    <ellipse cx="1000" cy="120" rx="160" ry="160"/>
  </g>
  <circle cx="1080" cy="90" r="10" fill="#8fa0d6"/>
  <defs><clipPath id="r"><rect x="920" y="360" width="160" height="160" rx="36"/></clipPath></defs>
  <image x="920" y="360" width="160" height="160" clip-path="url(#r)" xlink:href="data:image/png;base64,${iconB64}"/>
  <text x="80" y="330" font-family="Noto Sans CJK JP, Noto Sans JP, Inter, sans-serif" font-size="124" font-weight="700" letter-spacing="-2" fill="#eceef5">るーとの研究室</text>
  <text x="84" y="420" font-family="IBM Plex Mono, DejaVu Sans Mono, monospace" font-size="34" letter-spacing="1" fill="#8fa0d6">Root's Laboratory</text>
  <text x="84" y="490" font-family="IBM Plex Mono, DejaVu Sans Mono, monospace" font-size="24" letter-spacing="1" fill="#7d869a">Astronomy / Physics / Software / Quiz</text>
</svg>`;
await sharp(Buffer.from(og)).png({ compressionLevel: 9 }).toFile(path.join(pub, 'og-default.png'));

console.log('icons generated');
