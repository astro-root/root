import { defineConfig } from 'astro/config';
import cloudflare from '@astrojs/cloudflare';
import { dbMode } from './scripts/lib/mode.mjs';

// workerd が動かない環境（一部のARM Chromebook等）では、開発時だけ Node 標準の SQLite を使う。自動判定。
process.env.RL_NODE_DB = dbMode() === 'node' ? '1' : '0';
const NODE_DB = process.env.RL_NODE_DB === '1';

export default defineConfig({
  site: process.env.SITE_URL || 'https://astro-root.com',
  output: 'server',
  adapter: cloudflare({
    imageService: 'passthrough',
    platformProxy: {
      enabled: !NODE_DB,
      // E2Eテストなどで開発用DBと分離したいとき: D1_PERSIST_DIR=.e2e/state
      persist: process.env.D1_PERSIST_DIR ? { path: `${process.env.D1_PERSIST_DIR}/v3` } : true
    }
  }),
  // Astro標準の checkOrigin は HEAD まで 403 にしてしまう（4.16時点）ため無効化し、
  // src/middleware.ts で全パスの変更系リクエスト(GET/HEAD/OPTIONS以外)に同等のOrigin検査を行っている。
  security: { checkOrigin: false },
  // 開発サーバー(Vite)のホスト検査: GitHub Codespaces 等のプロキシ経由の公開URLを許可する（本番には影響しない）
  vite: { server: { allowedHosts: ['.github.dev', '.githubpreview.dev', '.gitpod.io'] } },
  compressHTML: true,
  build: { inlineStylesheets: 'auto' }
});
